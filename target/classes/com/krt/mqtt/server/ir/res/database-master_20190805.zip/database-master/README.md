# IRext database

This repository contains the IRext remote control index and IR binary code.

- binaries : The IR binary code
- db : IRext index data SQL script for MySQL and SQLite3 file
